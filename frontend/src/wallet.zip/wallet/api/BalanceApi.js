import { api } from "../../config/apiConfig";

/**
 * GET /balance
 * Uses HttpSession attribute "metroCardNumber" (handled via withCredentials: true in apiConfig)
 * Response: Double (current wallet balance)
 */
export const getBalanceApi = async () => {
  const response = await api.get("/balance");
  return response.data;
};

/**
 * PUT /balance?money=...
 * Request Param: money (Double, >= 0)
 * Response: String ("Successfully balance recharged", 202 ACCEPTED)
 */
export const addBalanceApi = async (money) => {
  const response = await api.put("/balance", null, {
    params: { money },
  });
  return response.data;
};
