import {
  FETCH_BALANCE_REQUEST,
  FETCH_BALANCE_SUCCESS,
  FETCH_BALANCE_FAILURE,
  ADD_BALANCE_REQUEST,
  ADD_BALANCE_SUCCESS,
  ADD_BALANCE_FAILURE,
  CLEAR_WALLET_MESSAGES,
} from "./ActionType";
import { getBalanceApi, addBalanceApi } from "../../api/BalanceApi";
import { extractApiError } from "../../../config/apiConfig";

export const fetchBalance = () => async (dispatch) => {
  dispatch({ type: FETCH_BALANCE_REQUEST });
  try {
    const balance = await getBalanceApi();
    dispatch({
      type: FETCH_BALANCE_SUCCESS,
      payload: Number(balance ?? 0),
    });
  } catch (error) {
    dispatch({
      type: FETCH_BALANCE_FAILURE,
      payload: extractApiError(error, "Unable to retrieve Metro Card balance."),
    });
  }
};

export const addBalance = (money, onSuccess) => async (dispatch) => {
  dispatch({ type: ADD_BALANCE_REQUEST });
  try {
    const message = await addBalanceApi(money);
    dispatch({
      type: ADD_BALANCE_SUCCESS,
      payload: {
        message: typeof message === "string" ? message : "Successfully balance recharged",
        addedAmount: Number(money),
      },
    });
    // Refresh exact server balance immediately after recharge
    dispatch(fetchBalance());
    if (onSuccess) onSuccess(message);
  } catch (error) {
    dispatch({
      type: ADD_BALANCE_FAILURE,
      payload: extractApiError(error, "Failed to recharge balance."),
    });
  }
};

export const clearWalletMessages = () => ({
  type: CLEAR_WALLET_MESSAGES,
});
