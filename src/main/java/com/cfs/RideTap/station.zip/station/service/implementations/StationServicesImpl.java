package com.cfs.RideTap.station.service.implementations;

import com.cfs.RideTap.station.dto.request.AddStationRequest;
import com.cfs.RideTap.station.dto.response.RouteResultDTO;
import com.cfs.RideTap.station.dto.response.RouteStepDTO;
import com.cfs.RideTap.station.model.Station;
import com.cfs.RideTap.station.repository.StationRepository;
import com.cfs.RideTap.station.service.implementations.MultiCityMetroNetworkSeeder.Edge;
import com.cfs.RideTap.station.service.interfaces.StationServices;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class StationServicesImpl implements StationServices {

  @Autowired
  private StationRepository stationRepository;

  @Autowired
  private MultiCityMetroNetworkSeeder networkSeeder;

  @Data
  @AllArgsConstructor
  private static class DijkstraNode implements Comparable<DijkstraNode> {
    private String stationName;
    private String currentLine;
    private String currentLineColor;
    private int cost; // weighted cost (stops * 10 + interchange penalty 3)
    private int stops;
    private int interchanges;

    @Override
    public int compareTo(DijkstraNode other) {
      return Integer.compare(this.cost, other.cost);
    }
  }

  @Data
  @AllArgsConstructor
  private static class PrevHop {
    private String prevStation;
    private String prevLine;
    private String edgeLine;
    private String edgeColor;
  }

  @Override
  public Station add(AddStationRequest addStationRequest) throws ResponseStatusException {
    String cleanName = addStationRequest.getName().trim();
    if (stationRepository.existsByNameIgnoreCase(cleanName)) {
      throw new ResponseStatusException(HttpStatus.CONFLICT, "Station already exists with this name");
    }

    Long maxSequence = stationRepository.findMaxSequenceNumber();
    List<String> lines = (addStationRequest.getLines() != null && !addStationRequest.getLines().isEmpty())
        ? addStationRequest.getLines()
        : List.of("Custom Extension Line");
    List<String> colors = (addStationRequest.getLineColors() != null && !addStationRequest.getLineColors().isEmpty())
        ? addStationRequest.getLineColors()
        : List.of("#0D9488");

    Station station = new Station();
    station.setName(cleanName);
    station.setSequenceNumber(maxSequence + 1);
    station.setLines(new ArrayList<>(lines));
    station.setLineColors(new ArrayList<>(colors));
    station.setInterchange(lines.size() > 1);

    Station saved = stationRepository.save(station);

    if (addStationRequest.getConnectToStation() != null && !addStationRequest.getConnectToStation().isBlank()) {
      networkSeeder.addDynamicEdge(
              addStationRequest.getCity(), // Pass the city parameter first
              cleanName,
              addStationRequest.getConnectToStation().trim(),
              lines.get(0),
              colors.get(0)
      );
    }

    return saved;
  }

  @Override
  public List<Station> findAll() {
    return stationRepository.findAllByOrderBySequenceNumberAsc();
  }

  @Override
  public List<Station> searchStations(String query, String line) {
    List<Station> base = (query != null && !query.isBlank())
        ? stationRepository.findByNameContainingIgnoreCaseOrderBySequenceNumberAsc(query.trim())
        : stationRepository.findAllByOrderBySequenceNumberAsc();

    if (line != null && !line.isBlank() && !"ALL".equalsIgnoreCase(line.trim())) {
      String targetLine = line.trim().toLowerCase(Locale.ROOT);
      return base.stream()
          .filter(s -> s.getLines() != null && s.getLines().stream()
              .anyMatch(l -> l.toLowerCase(Locale.ROOT).contains(targetLine)))
          .collect(Collectors.toList());
    }
    return base;
  }

  /**
   * Dijkstra's Shortest-Path Algorithm over the multi-line Delhi Metro graph.
   * Minimizes total stops while applying a mild interchange penalty so commuters
   * avoid unnecessary line switches when an equal-stop direct line exists.
   */
  @Override
  public RouteResultDTO findShortestRoute(String originName, String destinationName)
      throws ResponseStatusException {

    Station origin = stationRepository.findByNameIgnoreCase(originName.trim())
        .orElseThrow(() -> new ResponseStatusException(
            HttpStatus.BAD_REQUEST, "Origin station not found: " + originName));

    Station destination = stationRepository.findByNameIgnoreCase(destinationName.trim())
        .orElseThrow(() -> new ResponseStatusException(
            HttpStatus.BAD_REQUEST, "Destination station not found: " + destinationName));

    String startName = origin.getName();
    String endName = destination.getName();
    String startKey = MultiCityMetroNetworkSeeder.normalize(startName);
    String endKey = MultiCityMetroNetworkSeeder.normalize(endName);

    if (startKey.equals(endKey)) {
      String defaultLine = origin.getLines().isEmpty() ? "Metro Line" : origin.getLines().get(0);
      String defaultColor = origin.getLineColors().isEmpty() ? "#0D9488" : origin.getLineColors().get(0);
      return RouteResultDTO.builder()
          .originStation(startName)
          .destinationStation(endName)
          .totalStops(0)
          .interchanges(0)
          .estimatedMinutes(0)
          .fare(10.0)
          .linesUsed(List.of(defaultLine))
          .path(List.of(RouteStepDTO.builder()
              .stationId(origin.getId())
              .stationName(startName)
              .line(defaultLine)
              .lineColor(defaultColor)
              .interchangeHere(false)
              .build()))
          .build();
    }

    Map<String, List<Edge>> graph = networkSeeder.getAdjacencyGraph();
    Map<String, Station> dbStationLookup = stationRepository.findAll().stream()
        .collect(Collectors.toMap(
            s -> MultiCityMetroNetworkSeeder.normalize(s.getName()),
            s -> s,
            (a, b) -> a
        ));

    // State key: normalizedStation + "|" + lineName
    Map<String, Integer> dist = new HashMap<>();
    Map<String, PrevHop> parent = new HashMap<>();
    PriorityQueue<DijkstraNode> pq = new PriorityQueue<>();

    String initState = startKey + "|START";
    dist.put(initState, 0);
    pq.offer(new DijkstraNode(startName, "START", "#0D9488", 0, 0, 0));

    String bestEndState = null;
    int bestEndCost = Integer.MAX_VALUE;

    while (!pq.isEmpty()) {
      DijkstraNode curr = pq.poll();
      String currKey = MultiCityMetroNetworkSeeder.normalize(curr.getStationName());
      String currState = currKey + "|" + curr.getCurrentLine();

      if (curr.getCost() > dist.getOrDefault(currState, Integer.MAX_VALUE)) {
        continue;
      }

      if (currKey.equals(endKey)) {
        if (curr.getCost() < bestEndCost) {
          bestEndCost = curr.getCost();
          bestEndState = currState;
        }
        break;
      }

      List<Edge> neighbors = graph.getOrDefault(currKey, Collections.emptyList());
      for (Edge edge : neighbors) {
        String nextKey = MultiCityMetroNetworkSeeder.normalize(edge.getToStation());
        boolean isSwitch = !"START".equals(curr.getCurrentLine())
            && !curr.getCurrentLine().equals(edge.getLine());

        int stepCost = (edge.getWeight() * 10) + (isSwitch ? 4 : 0);
        int newCost = curr.getCost() + stepCost;
        String nextState = nextKey + "|" + edge.getLine();

        if (newCost < dist.getOrDefault(nextState, Integer.MAX_VALUE)) {
          dist.put(nextState, newCost);
          parent.put(nextState, new PrevHop(
              curr.getStationName(),
              curr.getCurrentLine(),
              edge.getLine(),
              edge.getLineColor()
          ));
          pq.offer(new DijkstraNode(
              edge.getToStation(),
              edge.getLine(),
              edge.getLineColor(),
              newCost,
              curr.getStops() + 1,
              curr.getInterchanges() + (isSwitch ? 1 : 0)
          ));
        }
      }
    }

    if (bestEndState == null) {
      // Fallback if disconnected custom station
      long fallbackStops = Math.max(1L, Math.abs(origin.getSequenceNumber() - destination.getSequenceNumber()));
      double fallbackFare = computeDMRCFare((int) fallbackStops);
      String lineA = origin.getLines().isEmpty() ? "Delhi Metro" : origin.getLines().get(0);
      String colorA = origin.getLineColors().isEmpty() ? "#0D9488" : origin.getLineColors().get(0);
      return RouteResultDTO.builder()
          .originStation(startName)
          .destinationStation(endName)
          .totalStops((int) fallbackStops)
          .interchanges(0)
          .estimatedMinutes(fallbackStops * 2.5)
          .fare(fallbackFare)
          .linesUsed(List.of(lineA))
          .path(List.of(
              RouteStepDTO.builder().stationId(origin.getId()).stationName(startName).line(lineA).lineColor(colorA).build(),
              RouteStepDTO.builder().stationId(destination.getId()).stationName(endName).line(lineA).lineColor(colorA).build()
          ))
          .build();
    }

    // Reconstruct path
    LinkedList<RouteStepDTO> steps = new LinkedList<>();
    String cursorState = bestEndState;
    String cursorStationName = endName;

    while (parent.containsKey(cursorState)) {
      PrevHop hop = parent.get(cursorState);
      Station stEntity = dbStationLookup.get(MultiCityMetroNetworkSeeder.normalize(cursorStationName));
      steps.addFirst(RouteStepDTO.builder()
          .stationId(stEntity != null ? stEntity.getId() : null)
          .stationName(stEntity != null ? stEntity.getName() : cursorStationName)
          .line(hop.getEdgeLine())
          .lineColor(hop.getEdgeColor())
          .interchangeHere(false)
          .build());

      cursorStationName = hop.getPrevStation();
      cursorState = MultiCityMetroNetworkSeeder.normalize(hop.getPrevStation()) + "|" + hop.getPrevLine();
    }

    // Prepend origin station with the first outgoing edge's line/color
    String firstLine = steps.isEmpty() ? "Delhi Metro" : steps.getFirst().getLine();
    String firstColor = steps.isEmpty() ? "#0D9488" : steps.getFirst().getLineColor();
    steps.addFirst(RouteStepDTO.builder()
        .stationId(origin.getId())
        .stationName(startName)
        .line(firstLine)
        .lineColor(firstColor)
        .interchangeHere(false)
        .build());

    // Mark interchanges and collect distinct lines used
    List<String> linesUsed = new ArrayList<>();
    int interchanges = 0;
    for (int i = 0; i < steps.size(); i++) {
      RouteStepDTO step = steps.get(i);
      if (!linesUsed.contains(step.getLine())) {
        linesUsed.add(step.getLine());
      }
      if (i > 0 && !steps.get(i - 1).getLine().equals(step.getLine())) {
        steps.get(i - 1).setInterchangeHere(true);
        interchanges++;
      }
    }

    int totalStops = Math.max(0, steps.size() - 1);
    double fare = computeDMRCFare(totalStops);
    double estimatedMinutes = Math.round(((totalStops * 2.2) + (interchanges * 5.0)) * 10.0) / 10.0;

    return RouteResultDTO.builder()
        .originStation(startName)
        .destinationStation(endName)
        .totalStops(totalStops)
        .interchanges(interchanges)
        .estimatedMinutes(estimatedMinutes)
        .fare(fare)
        .linesUsed(linesUsed)
        .path(steps)
        .build();
  }

  /**
   * Realistic DMRC slab-based fare calculation based on Dijkstra shortest-path stop count:
   * 0-2 stops: ₹10 | 3-5 stops: ₹20 | 6-12 stops: ₹30 | 13-21 stops: ₹40 | 22-32 stops: ₹50 | 33+ stops: ₹60
   */
  public static double computeDMRCFare(int stops) {
    if (stops <= 2) return 10.0;
    if (stops <= 5) return 20.0;
    if (stops <= 12) return 30.0;
    if (stops <= 21) return 40.0;
    if (stops <= 32) return 50.0;
    return 60.0;
  }

  @Override
  public boolean existsById(Long id) {
    return stationRepository.existsById(id);
  }

  @Override
  public Station findById(Long id) throws ResponseStatusException {
    return stationRepository.findById(id)
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Station not found by provided id"));
  }

  @Override
  public Optional<Station> findByName(String name) {
    if (name == null) return Optional.empty();
    return stationRepository.findByNameIgnoreCase(name.trim());
  }

  @Override
  public void deleteById(Long id) throws ResponseStatusException {
    if (!stationRepository.existsById(id)) {
      throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Station not found by provided id");
    }
    stationRepository.deleteById(id);
  }

  @Override
  public void deleteAll() {
    stationRepository.deleteAll();
  }
}
